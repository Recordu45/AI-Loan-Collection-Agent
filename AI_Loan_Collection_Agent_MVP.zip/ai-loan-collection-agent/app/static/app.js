const $ = (s) => document.querySelector(s);
let customerCache = [];
const money = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(Number(n||0));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),3000)}
async function api(url, options={}){const headers=options.body instanceof FormData?{}:{'Content-Type':'application/json'};const res=await fetch(url,{...options,headers:{...headers,...options.headers}});if(res.status===401){location.href='/login';throw new Error('Please log in')}let data;try{data=await res.json()}catch{data=null}if(!res.ok)throw new Error(data?.detail||'Request failed');return data}
async function loadDashboard(){const d=await api('/api/dashboard');const cards=[
['Assigned customers',d.total_customers,'Records currently in workspace'],
['Calls attempted',d.calls_attempted,'Simulated outcomes logged'],
['Calls answered',d.calls_answered,`${d.answer_rate}% answer rate`],
['Promise to pay',d.ptp_count,'PTP commitments recorded'],
['Payments verified',d.payments_verified,'Verified-paid records'],
['Needs follow-up',d.follow_up,'Includes human-review holds'],
['No answer',d.failed_calls,'Failed simulated attempts'],
['Callback requests',d.callback_requests,'Customer requested callback']
];$('#metrics').innerHTML=cards.map(c=>`<div class="metric"><div class="label">${c[0]}</div><div class="value">${c[1]}</div><div class="sub">${c[2]}</div></div>`).join('')}
async function loadBranches(){const list=await api('/api/branches');$('#branchFilter').innerHTML='<option value="">All branches</option>'+list.map(b=>`<option value="${esc(b)}">${esc(b)}</option>`).join('')}
async function loadCustomers(){const p=new URLSearchParams({q:$('#search').value,status:$('#statusFilter').value,branch:$('#branchFilter').value});customerCache=await api('/api/customers?'+p);$('#customerCount').textContent=`Showing ${customerCache.length} record(s) (maximum 500 per view)`;$('#customersBody').innerHTML=customerCache.length?customerCache.map(c=>`<tr><td><div class="customer-name">${esc(c.customer_name)}</div><div class="phone">${esc(c.phone)}</div></td><td>${esc(c.masked_loan_ref)}</td><td>${esc(c.due_date)}</td><td>${money(c.outstanding_amount)}</td><td><span class="status status-${esc(c.payment_status)}">${esc(c.payment_status)}</span></td><td>${c.suppressed?'<span class="status status-disputed">Review hold</span>':c.follow_up_required?'Required':'—'}</td><td><div class="actions"><button class="mini" data-call="${c.id}" ${c.payment_status==='paid'||c.suppressed?'disabled':''}>Simulate call</button>${c.payment_status!=='paid'?`<button class="mini" data-paid="${c.id}">Mark verified paid</button>`:''}</div></td></tr>`).join(''):'<tr><td colspan="7">No matching records found.</td></tr>';document.querySelectorAll('[data-call]').forEach(b=>b.onclick=()=>openCall(Number(b.dataset.call)));document.querySelectorAll('[data-paid]').forEach(b=>b.onclick=()=>markPaid(Number(b.dataset.paid)))}
async function loadCalls(){const rows=await api('/api/calls');$('#callsList').innerHTML=rows.length?rows.slice(0,12).map(r=>`<div class="call-row"><div><strong>${esc(r.customer_name)}</strong><small>${esc(r.call_at.replace('T',' '))} · ${r.simulated?'Simulated':''}${r.ptp_date?' · PTP '+esc(r.ptp_date):''}</small></div><span class="status ${r.outcome==='answered_ptp'?'status-paid':r.outcome==='no_answer'?'status-overdue':'status-upcoming'}">${esc(r.outcome_label)}</span></div>`).join(''):'<p class="muted">No outcomes recorded yet. Use “Simulate call” on a demo record to test the workflow.</p>'}
async function loadAudit(){try{const me=await api('/api/me');if(me.role!=='admin')return;$('#auditPanel').hidden=false;const rows=await api('/api/audit');$('#auditBody').innerHTML=rows.map(r=>`<tr><td>${esc(r.at.replace('T',' '))}</td><td>${esc(r.username)}</td><td>${esc(r.action)}</td><td>${esc(r.entity_type)} #${esc(r.entity_id)}</td><td>${esc(r.details)}</td></tr>`).join('')||'<tr><td colspan="5">No audit events.</td></tr>'}catch(e){console.warn(e)}}
async function refresh(){try{await Promise.all([loadDashboard(),loadBranches(),loadCustomers(),loadCalls(),loadAudit()])}catch(e){toast(e.message)}}
$('#search').addEventListener('input',()=>{clearTimeout(window.searchTimer);window.searchTimer=setTimeout(loadCustomers,250)});
$('#statusFilter').onchange=loadCustomers;$('#branchFilter').onchange=loadCustomers;
$('#addBtn').onclick=()=>{$('#customerForm').reset();$('#modal').hidden=false};
$('#closeModal').onclick=()=>$('#modal').hidden=true;
$('#customerForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const p=Object.fromEntries(f.entries());p.outstanding_amount=Number(p.outstanding_amount);try{await api('/api/customers',{method:'POST',body:JSON.stringify(p)});$('#modal').hidden=true;toast('Customer saved');await refresh()}catch(err){toast(err.message)}};
async function markPaid(id){if(!confirm('Only continue after verifying payment in the lender’s authorized source. Mark this record as verified paid?'))return;try{await api(`/api/customers/${id}/payment`,{method:'POST',body:JSON.stringify({payment_status:'paid'})});toast('Payment status updated; reminders suppressed');await refresh()}catch(e){toast(e.message)}}
function openCall(id){const c=customerCache.find(x=>x.id===id);if(!c)return;$('#callForm').reset();$('#callForm [name=customer_id]').value=id;$('#callTitle').textContent='Simulate call · '+c.customer_name;const today=new Date();$('#callForm [name=ptp_date]').min=today.toISOString().slice(0,10);$('#callForm [name=ptp_date]').value=today.toISOString().slice(0,10);$('#callModal').hidden=false;togglePtp()}
function togglePtp(){$('#ptpFields').hidden=$('#outcomeSelect').value!=='answered_ptp'}
$('#outcomeSelect').onchange=togglePtp;$('#closeCallModal').onclick=()=>$('#callModal').hidden=true;
$('#callForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),id=f.get('customer_id');const p={outcome:f.get('outcome'),ptp_date:f.get('ptp_date'),ptp_amount:f.get('ptp_amount'),notes:f.get('notes')};try{const r=await api(`/api/customers/${id}/call`,{method:'POST',body:JSON.stringify(p)});$('#callModal').hidden=true;toast(r.message);await refresh()}catch(err){toast(err.message)}};
$('#importBtn').onclick=()=>$('#csvFile').click();
$('#csvFile').onchange=async e=>{const file=e.target.files[0];if(!file)return;const form=new FormData();form.append('file',file);try{const r=await api('/api/customers/import',{method:'POST',body:form});toast(`Imported ${r.imported} records`);await refresh()}catch(err){toast(err.message)}finally{e.target.value=''}};
$('#refreshAudit').onclick=loadAudit;
refresh();
